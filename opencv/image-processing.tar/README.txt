we submitted this project with the four images based on flower.JPG, but feel free to run our code on rectangles.jpg or greenpaper.JPG.

Ryan Houck, David Fletcher, Jordan Wood
